package com.example.demoapi_kel3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoapiKel3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
